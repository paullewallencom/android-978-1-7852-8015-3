package com.geniesoftstudios.androidtvinterfaces;

import android.app.Activity;
import android.os.Bundle;

/**
 * Created by Steven Daniel on 12/06/2015.
 */
public class TVSearchActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);
    }

}
